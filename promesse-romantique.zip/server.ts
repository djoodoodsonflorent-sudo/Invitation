import express from "express";
import { createServer as createViteServer } from "vite";
import { Resend } from 'resend';
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for confirmation email
  app.post("/api/confirm", async (req, res) => {
    const { email, message } = req.body;
    const resendApiKey = process.env.RESEND_API_KEY;

    if (!resendApiKey) {
      console.warn("RESEND_API_KEY is missing. Email skipped.");
      return res.status(200).json({ success: true, warning: "Key missing" });
    }

    const resend = new Resend(resendApiKey);

    try {
      const { data, error } = await resend.emails.send({
        from: 'Cupid <onboarding@resend.dev>',
        to: email || 'djoodoodsonflorent@gmail.com', // Fallback to user email if provided
        subject: '❤️ Elle a dit OUI !',
        html: `
          <div style="font-family: sans-serif; background: #fff1f2; padding: 40px; border-radius: 20px; text-align: center;">
            <h1 style="color: #e11d48; margin-bottom: 20px;">Bonne nouvelle ! 🌹</h1>
            <p style="font-size: 18px; color: #4c0519;">La personne a accepté ton invitation pour :</p>
            <blockquote style="background: white; padding: 20px; border-radius: 10px; border-left: 5px solid #e11d48; font-style: italic; color: #881337;">
              "${message}"
            </blockquote>
            <p style="margin-top: 30px; font-weight: bold; color: #e11d48;">Prépare-toi pour un moment magique ! ✨</p>
          </div>
        `
      });

      if (error) {
        console.error("Email error:", error);
        return res.status(500).json({ error });
      }

      res.status(200).json({ data });
    } catch (err) {
      console.error("Server error:", err);
      res.status(500).json({ error: "Server Error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
