import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Copy, Check, Send, Sparkles, Star, Feather } from 'lucide-react';
import confetti from 'canvas-confetti';

const Stars = () => {
  const [stars, setStars] = useState<{ id: number; top: string; left: string; size: number; duration: string }[]>([]);

  useEffect(() => {
    const newStars = Array.from({ length: 100 }).map((_, i) => ({
      id: i,
      top: `${Math.random() * 100}%`,
      left: `${Math.random() * 100}%`,
      size: Math.random() * 2 + 1,
      duration: `${Math.random() * 3 + 2}s`,
    }));
    setStars(newStars);
  }, []);

  return (
    <div className="stars-container">
      {stars.map((star) => (
        <div
          key={star.id}
          className="star"
          style={{
            top: star.top,
            left: star.left,
            width: `${star.size}px`,
            height: `${star.size}px`,
            '--duration': star.duration,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const HeartSnow = () => {
  const [hearts, setHearts] = useState<{ id: number; left: string; size: number; duration: string; delay: string; opacity: number }[]>([]);

  useEffect(() => {
    const newHearts = Array.from({ length: 40 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      size: Math.random() * (20 - 10) + 10,
      duration: `${Math.random() * (15 - 8) + 8}s`,
      delay: `${Math.random() * 10}s`,
      opacity: Math.random() * 0.5 + 0.3,
    }));
    setHearts(newHearts);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-10">
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="snowing-heart"
          style={{
            left: heart.left,
            width: `${heart.size}px`,
            height: `${heart.size}px`,
            '--duration': heart.duration,
            animationDelay: heart.delay,
            opacity: heart.opacity,
          } as React.CSSProperties}
        >
          <Heart className="w-full h-full text-love-red fill-love-red" />
        </div>
      ))}
    </div>
  );
};

export default function App() {
  const [params, setParams] = useState(new URLSearchParams(window.location.search));
  const messageFromUrl = useMemo(() => params.get('msg'), [params]);
  const successFromUrl = useMemo(() => params.get('success'), [params]);
  const emailFromUrl = useMemo(() => params.get('email'), [params]);
  
  const [generatorInput, setGeneratorInput] = useState('');
  const [successMessageInput, setSuccessMessageInput] = useState("J'ai hâte de te revoir !");
  const [senderEmail, setSenderEmail] = useState('djoodoodsonflorent@gmail.com');
  const [generatedLink, setGeneratedLink] = useState('');
  const [copied, setCopied] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  const [hasMoved, setHasMoved] = useState(false);
  
  const noButtonRef = useRef<HTMLButtonElement>(null);

  // Typing effect hook
  const useTypingEffect = (text: string, speed: number = 50) => {
    const [displayedText, setDisplayedText] = useState('');
    const [isFinished, setIsFinished] = useState(false);

    useEffect(() => {
      setDisplayedText('');
      setIsFinished(false);
      let i = 0;
      const timer = setInterval(() => {
        if (i < text.length) {
          setDisplayedText((prev) => prev + text.charAt(i));
          i++;
        } else {
          clearInterval(timer);
          setIsFinished(true);
        }
      }, speed);
      return () => clearInterval(timer);
    }, [text, speed]);

    return { displayedText, isFinished };
  };

  const decodedMessage = useMemo(() => 
    messageFromUrl ? decodeURIComponent(messageFromUrl) : '', 
    [messageFromUrl]
  );
  
  const { displayedText, isFinished } = useTypingEffect(decodedMessage, 144);
  const decodedSuccess = useMemo(() => successFromUrl ? decodeURIComponent(successFromUrl) : "J'ai hâte de te revoir !", [successFromUrl]);
  const { displayedText: successText, isFinished: successFinished } = useTypingEffect(isSuccess ? decodedSuccess : "", 120);

  // Dynamic font size based on message length
  const fontSizeClass = useMemo(() => {
    const len = decodedMessage.length;
    if (len > 100) return 'text-2xl md:text-3xl';
    if (len > 50) return 'text-3xl md:text-5xl';
    return 'text-5xl md:text-7xl';
  }, [decodedMessage]);

  useEffect(() => {
    const handlePopState = () => {
      setParams(new URLSearchParams(window.location.search));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleCreateLink = () => {
    if (!generatorInput.trim()) return;
    const baseUrl = window.location.origin + window.location.pathname;
    let link = `${baseUrl}?msg=${encodeURIComponent(generatorInput)}`;
    if (successMessageInput.trim()) {
      link += `&success=${encodeURIComponent(successMessageInput)}`;
    }
    if (senderEmail.trim()) {
      link += `&email=${encodeURIComponent(senderEmail)}`;
    }
    setGeneratedLink(link);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy!', err);
    }
  };

  const moveNoButton = () => {
    if (!noButtonRef.current) return;
    
    const btnWidth = noButtonRef.current.offsetWidth || 100;
    const btnHeight = noButtonRef.current.offsetHeight || 50;
    const padding = 20;

    const maxX = window.innerWidth - btnWidth - padding;
    const maxY = window.innerHeight - btnHeight - padding;

    const newX = Math.max(padding, Math.floor(Math.random() * maxX));
    const newY = Math.max(padding, Math.floor(Math.random() * maxY));

    setNoButtonPos({ x: newX, y: newY });
    setHasMoved(true);
  };

  const handleYes = async () => {
    setIsSuccess(true);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#fb7185', '#e11d48', '#ffe4e6', '#d4af37'],
    });

    // Send confirmation email
    if (emailFromUrl) {
      try {
        await fetch('/api/confirm', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: emailFromUrl,
            message: decodedMessage
          })
        });
      } catch (err) {
        console.error("Failed to send confirmation email", err);
      }
    }

    // Cinematic transition: everything fades out after 6 seconds
    setTimeout(() => {
      setIsFadingOut(true);
    }, 6000);
  };

  useEffect(() => {
    if (messageFromUrl) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [messageFromUrl]);

  return (
    <div className={`min-h-screen w-full flex items-center justify-center p-6 bg-romantic-bg relative ${messageFromUrl ? 'overflow-hidden' : 'py-12 overflow-y-auto'}`}>
      <Stars />
      <HeartSnow />
      
      <div className="relative z-20 w-full max-w-2xl flex items-center justify-center">
        <AnimatePresence mode="wait">
          {!isFadingOut && (
            <AnimatePresence mode="wait">
              {messageFromUrl ? (
                <motion.div
                  key="invitation"
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ opacity: 0, filter: "blur(40px)", scale: 1.05 }}
                  transition={{ duration: 3.5, ease: "easeInOut" }}
                  className="w-full"
                >
              {isSuccess ? (
                <motion.div 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="p-12 rounded-[2.5rem] text-center w-full"
                >
                  <div className="relative inline-block mb-8">
                    <motion.div
                      animate={{ 
                        scale: [1, 1.2, 1],
                        rotate: [0, 10, -10, 0]
                      }}
                      transition={{ repeat: Infinity, duration: 2 }}
                    >
                      <Heart className="w-20 h-20 text-love-red fill-love-red" />
                    </motion.div>
                    <motion.div
                      animate={{ scale: [0, 1.5, 0], opacity: [0, 0.8, 0] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      className="absolute -top-4 -right-4"
                    >
                      <Sparkles className="w-10 h-10 text-gold-accent" />
                    </motion.div>
                  </div>
                  
                  <h2 className="text-4xl font-serif font-black text-white mb-6 tracking-tight">
                    C'est un OUI ! ❤️
                  </h2>
                  <div className="min-h-[100px] flex items-center justify-center">
                    <h3 className="text-4xl md:text-5xl font-calligraphy font-normal text-white text-center leading-relaxed tracking-wider break-words w-full relative drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
                      {successText}
                      {!successFinished && isSuccess && (
                        <motion.div
                          animate={{ 
                            rotate: [15, 25, 15],
                            x: [0, 2, 0],
                            y: [0, -2, 0]
                          }}
                          transition={{ 
                            repeat: Infinity, 
                            duration: 0.5 
                          }}
                          className="inline-block align-middle ml-2"
                        >
                          <Feather className="w-8 h-8 md:w-12 md:h-12 text-rose-200/80 -rotate-45" />
                        </motion.div>
                      )}
                    </h3>
                  </div>
                  
                  <div className="mt-10 flex justify-center gap-2">
                    {[...Array(3)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-gold-accent fill-gold-accent opacity-40" />
                    ))}
                  </div>
                </motion.div>
              ) : (
                <div className="p-8 md:p-16 text-center w-full relative group max-h-[90vh] flex flex-col items-center justify-center overflow-y-auto custom-scrollbar">
                  <div className="shrink-0" />
                  
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="w-full flex flex-col items-center"
                  >
                    <div className="font-handwritten text-love-red text-2xl mb-6">Pour toi...</div>
                    <h1 className={`${fontSizeClass} font-calligraphy font-normal text-white mb-12 leading-relaxed tracking-wider break-words w-full relative drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]`}>
                      {displayedText}
                      {!isFinished && (
                        <motion.div
                          animate={{ 
                            rotate: [15, 25, 15],
                            x: [0, 2, 0],
                            y: [0, -2, 0]
                          }}
                          transition={{ 
                            repeat: Infinity, 
                            duration: 0.5 
                          }}
                          className="inline-block align-middle ml-2"
                        >
                          <Feather className="w-10 h-10 md:w-16 md:h-16 text-rose-200/80 -rotate-45" />
                        </motion.div>
                      )}
                    </h1>
                    
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: isFinished ? 1 : 0 }}
                      className="flex flex-col sm:flex-row items-center justify-center gap-8 mt-4 w-full shrink-0"
                    >
                      <motion.button
                        whileHover={{ scale: 1.05, boxShadow: "0 10px 20px rgba(251, 113, 133, 0.3)" }}
                        whileTap={{ scale: 0.95 }}
                        animate={isFinished ? {
                          scale: [1, 1.05, 1],
                        } : {}}
                        transition={isFinished ? {
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        } : {}}
                        onClick={handleYes}
                        className="px-12 py-5 bg-gradient-to-br from-love-red to-rose-600 text-white rounded-2xl font-bold text-2xl shadow-xl shadow-love-red/20 transition-all cursor-pointer relative overflow-hidden group/btn"
                      >
                        <span className="relative z-10">Oui ! 💖</span>
                        <div className="absolute inset-0 bg-white/20 translate-y-full group-hover/btn:translate-y-0 transition-transform duration-300" />
                      </motion.button>

                      <motion.button
                        ref={noButtonRef}
                        style={hasMoved ? { 
                          position: 'fixed', 
                          left: noButtonPos.x, 
                          top: noButtonPos.y,
                          zIndex: 100 
                        } : {}}
                        onMouseEnter={moveNoButton}
                        onTouchStart={(e) => {
                          e.preventDefault();
                          moveNoButton();
                        }}
                        className="px-12 py-5 bg-white/10 text-gray-400 rounded-2xl font-bold text-2xl border-2 border-white/5 transition-colors"
                      >
                        Non 😢
                      </motion.button>
                    </motion.div>
                  </motion.div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="generator"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="p-10 md:p-14 rounded-[3rem] w-full relative overflow-hidden"
            >
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-love-red/10 rounded-full blur-3xl opacity-20" />
              <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-rose-900/10 rounded-full blur-3xl opacity-20" />
              
              <div className="relative z-10">
                <div className="flex items-center justify-center mb-4">
                  <div className="p-3 bg-white/5 rounded-2xl">
                    <Heart className="w-8 h-8 text-love-red fill-love-red/20" />
                  </div>
                </div>
                
                <h2 className="text-3xl md:text-4xl font-serif font-black text-white text-center mb-3">
                  Crée ton Invitation
                </h2>
                <div className="font-handwritten text-love-red text-center text-xl mb-10 opacity-70">Le lien qui ne connaît pas le non...</div>
                
                <p className="text-gray-400 text-center mb-10 leading-relaxed text-lg font-medium max-w-sm mx-auto">
                  Pose ta question ici. Ton destinataire aura un bouton "Non" fuyard... impossible de refuser !
                </p>

                  <div className="space-y-6">
                    <div className="relative group/input">
                      <label className="block text-gray-500 text-xs font-bold uppercase tracking-widest mb-3 ml-1">Ce que tu veux demander :</label>
                      <input
                        type="text"
                        value={generatorInput}
                        onChange={(e) => setGeneratorInput(e.target.value)}
                        placeholder="Ex: Veux-tu venir au resto ce soir ?"
                        className="w-full px-6 py-5 bg-white/5 border-2 border-white/10 rounded-2xl focus:border-love-red focus:ring-4 focus:ring-love-red/5 outline-none transition-all text-white text-xl shadow-sm placeholder:text-gray-600"
                      />
                    </div>

                    <div className="relative group/input">
                      <label className="block text-gray-500 text-xs font-bold uppercase tracking-widest mb-3 ml-1">Ton message après le "Oui" :</label>
                      <input
                        type="text"
                        value={successMessageInput}
                        onChange={(e) => setSuccessMessageInput(e.target.value)}
                        placeholder="Ex: J'ai trop hâte !"
                        className="w-full px-6 py-4 bg-white/5 border-2 border-white/10 rounded-xl focus:border-love-red focus:ring-4 focus:ring-love-red/5 outline-none transition-all text-white text-lg shadow-sm placeholder:text-gray-600"
                      />
                    </div>

                    <div className="relative group/input">
                      <label className="block text-gray-500 text-xs font-bold uppercase tracking-widest mb-3 ml-1 text-love-red">Ton email (pour recevoir la réponse) :</label>
                      <input
                        type="email"
                        value={senderEmail}
                        onChange={(e) => setSenderEmail(e.target.value)}
                        placeholder="ton@email.com"
                        className="w-full px-6 py-4 bg-white/5 border-2 border-white/10 rounded-xl focus:border-love-red focus:ring-4 focus:ring-love-red/5 outline-none transition-all text-white text-lg shadow-sm placeholder:text-gray-600"
                      />
                    </div>

                    <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleCreateLink}
                    disabled={!generatorInput.trim()}
                    className="w-full py-5 bg-white text-black hover:bg-gray-100 disabled:bg-gray-800 disabled:text-gray-600 rounded-2xl font-bold text-xl shadow-xl transition-all cursor-pointer flex items-center justify-center gap-3 active:scale-95"
                  >
                    <Send className="w-5 h-5" />
                    Générer mon lien magique
                  </motion.button>

                  <AnimatePresence>
                    {generatedLink && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="pt-6 border-t border-white/10 space-y-4 overflow-hidden"
                      >
                        <div className="text-sm font-bold text-gray-500 uppercase tracking-widest ml-1">Lien prêt à l'emploi :</div>
                        <div className="relative group">
                          <textarea
                            readOnly
                            value={generatedLink}
                            className="w-full p-5 bg-white/5 border-2 border-white/5 rounded-2xl text-base text-love-red font-medium h-24 resize-none focus:outline-none"
                          />
                          <button
                            onClick={copyToClipboard}
                            className="absolute bottom-4 right-4 p-4 bg-white shadow-lg rounded-2xl hover:bg-gray-100 transition-all flex items-center gap-3 border border-gray-100 group-hover:scale-105 active:scale-95 text-black"
                          >
                            {copied ? (
                              <>
                                <Check className="w-5 h-5 text-green-500" />
                                <span className="text-sm font-bold text-green-600">C'est fait !</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-5 h-5 text-black" />
                                <span className="text-sm font-bold text-gray-700">Copier</span>
                              </>
                            )}
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          )}
            </AnimatePresence>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
